# PremiumVPNShop Telegram Bot

আপনার স্ক্রিনশটের মতো একটি ডিজিটাল প্রোডাক্ট সেলিং বট (VPN, Proxy, ChatGPT Plus, Telegram Premium ইত্যাদি) — ক্যাটাগরি/স্টক/দাম সহ প্রোডাক্ট লিস্ট, Wallet balance, Top-up (bKash/Nagad/Binance) + TXN + Screenshot ভেরিফিকেশন, Admin approve সিস্টেম।

## ফিচার

- 🛡️ VPN Shop / 🌐 Proxy Shop — ইমোজি + Limit/Validity/Price/Stock সহ প্রোডাক্ট লিস্ট
- 💎 Products → ক্যাটাগরি সিলেক্ট (Pre-Order VPN, ChatGPT Plus, ABC Proxy, Telegram Premium)
- 👛 Balance দেখা, Wallet থেকে অটো ডিডাক্ট করে Buy করা
- 💳 Top-up: Method বাছুন → Amount দিন → TXN দিন → Screenshot পাঠান → Admin কে notify → Approve করলে balance যোগ হয়
- 🛒 Order দিলে Admin কে automatically notification যায় (credential ম্যানুয়ালি ডেলিভারি দিতে হবে)
- 🎁 Refer link, 📊 Status (order history)
- Admin commands দিয়ে stock/balance আপডেট করা যায়

## ইনস্টল করা

```bash
cd vpnshop_bot
pip install -r requirements.txt --break-system-packages   # অথবা virtualenv ব্যবহার করুন
cp .env.example .env
```

`.env` ফাইল খুলে বসান:
- `BOT_TOKEN` — @BotFather থেকে নেওয়া টোকেন
- `ADMIN_IDS` — আপনার Telegram user id (বট রান করার পর `/myid` কমান্ড পাঠিয়ে বের করুন)
- `BKASH_NUMBER` / `NAGAD_NUMBER` / `BINANCE_ID` — আপনার পেমেন্ট নাম্বার

## রান করা

```bash
python bot.py
```

VPS-এ ২৪/৭ চালাতে `pm2`, `systemd`, অথবা `screen`/`tmux` ব্যবহার করুন।

## প্রোডাক্ট এডিট করা

`data/products.json` ফাইলে সরাসরি এডিট করে নতুন item/category, দাম, স্টক বসাতে পারবেন। উদাহরণ:

```json
{
  "id": "hma_7",
  "name": "HMA VPN",
  "emoji": "🦄",
  "limit": "Unlimited",
  "validity": "7 দিন",
  "price_tk": 25,
  "price_usdt": 0.21,
  "stock": 1
}
```

দ্রুত স্টক বদলাতে বট থেকেও কমান্ড দিতে পারেন:

```
/stock vpn hma_7 5
```

## Admin কমান্ড

| কমান্ড | কাজ |
|---|---|
| `/myid` | নিজের Telegram user id দেখা |
| `/stock <category> <item_id> <qty>` | নির্দিষ্ট প্রোডাক্টের স্টক সেট করা |
| `/addbalance <user_id> <amount>` | কোনো ইউজারের ব্যালেন্সে ম্যানুয়াল টাকা যোগ করা |

Top-up request এলে Admin এর চ্যাটে ছবি + ✅ Approve / ❌ Reject বাটন সহ মেসেজ আসবে — বাটনে ক্লিক করলেই ইউজারের ব্যালেন্স আপডেট হয়ে যাবে।

## পরের ধাপে যা যোগ করতে পারেন

- Order দেওয়ার সাথে সাথেই automatic credential delivery (এখন Admin ম্যানুয়ালি পাঠায়)
- SQLite/PostgreSQL এ মাইগ্রেট করা (এখন JSON ফাইল ব্যবহার হচ্ছে, বড় স্কেলে সীমাবদ্ধতা আছে)
- Referral বোনাস সিস্টেম সম্পূর্ণ করা (এখন শুধু লিংক জেনারেট হয়)
- Multi-language toggle (বাংলা/English)

কোনো অংশ কাস্টমাইজ করতে চাইলে বলুন — যেমন নতুন পেমেন্ট মেথড, automatic delivery, বা আলাদা ক্যাটাগরি স্ট্রাকচার।
