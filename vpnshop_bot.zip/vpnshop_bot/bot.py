import logging

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ConversationHandler,
    ContextTypes,
    filters,
)

import storage
from config import BOT_TOKEN, ADMIN_IDS, SHOP_NAME, PAYMENT_METHODS
from keyboards import (
    main_menu_keyboard,
    category_products_keyboard,
    item_detail_keyboard,
    select_category_keyboard,
    topup_methods_keyboard,
    cancel_keyboard,
    admin_review_keyboard,
)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# Conversation states for the Top-up flow
TOPUP_AMOUNT, TOPUP_TXN, TOPUP_SCREENSHOT = range(3)


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


# ------------------------------------------------------------------
# /start and main menu
# ------------------------------------------------------------------

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    storage.get_user(user.id, name=user.full_name)
    text = (
        f"🏮 {SHOP_NAME} 🏮\n\n"
        f"👋 Welcome, {user.full_name}!\n\n"
        f"💎 Premium products — Fast delivery\n"
        f"🚀 Secure • Reliable • 24/7"
    )
    await update.message.reply_text(text, reply_markup=main_menu_keyboard())


async def show_category_message(update_or_query, cat_key: str, edit: bool = False):
    cat = storage.get_category(cat_key)
    if not cat:
        return
    lines = [f"{cat['icon']} {cat['title']}", "─" * 20]
    for item in cat["items"]:
        price_line = f"💰 Price: {item['price_tk']} TK" + (
            f" / OUT" if item["stock"] == 0 else f" / Stock: {item['stock']}"
        )
        lines.append(
            f"\n{item['emoji']} {item['name']}\n"
            f"👑 Limit: {item['limit']} / 📊 Validity: {item['validity']}\n"
            f"{price_line}"
        )
    lines.append("\n📍 একটি product বেছে নিন:")
    text = "\n".join(lines)
    kb = category_products_keyboard(cat_key, cat)
    if edit:
        await update_or_query.edit_message_text(text, reply_markup=kb)
    else:
        await update_or_query.message.reply_text(text, reply_markup=kb)


async def menu_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()

    if "Proxy Shop" in text:
        await show_category_message(update, "proxy")
    elif "VPN Shop" in text:
        await show_category_message(update, "vpn")
    elif "Products" in text:
        await update.message.reply_text(
            "💎 SELECT CATEGORY", reply_markup=select_category_keyboard()
        )
    elif "Top-up" in text:
        await update.message.reply_text(
            "💳 TOP-UP\n📍 পেমেন্ট মেথড বেছে নিন:", reply_markup=topup_methods_keyboard()
        )
    elif "Balance" in text:
        bal = storage.get_balance(update.effective_user.id)
        await update.message.reply_text(f"👛 আপনার Balance: {bal} TK")
    elif "Refer" in text:
        bot_username = (await context.bot.get_me()).username
        link = f"https://t.me/{bot_username}?start=ref{update.effective_user.id}"
        await update.message.reply_text(
            f"🎁 আপনার Referral Link:\n{link}\n\nবন্ধুদের শেয়ার করুন!"
        )
    elif "Status" in text:
        orders = storage.get_orders()["orders"]
        my_orders = [o for o in orders if o["user_id"] == update.effective_user.id]
        if not my_orders:
            await update.message.reply_text("📊 আপনার কোনো order history নেই।")
        else:
            lines = [f"#{o['id']} {o['item_name']} — {o['price_tk']} TK" for o in my_orders[-10:]]
            await update.message.reply_text("📊 আপনার সাম্প্রতিক Order:\n" + "\n".join(lines))
    elif "Support" in text:
        await update.message.reply_text("💬 সাহায্যের জন্য অ্যাডমিনের সাথে যোগাযোগ করুন।")
    else:
        await update.message.reply_text("দয়া করে নিচের মেনু থেকে একটি অপশন বেছে নিন।")


# ------------------------------------------------------------------
# Callback query router (inline buttons)
# ------------------------------------------------------------------

async def callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    await query.answer()

    if data == "close":
        await query.message.delete()
        return

    if data.startswith("cat:"):
        _, cat_key = data.split(":", 1)
        await show_category_message(query, cat_key, edit=True)
        return

    if data.startswith("item:"):
        _, cat_key, item_id = data.split(":", 2)
        item = storage.get_item(cat_key, item_id)
        if not item:
            await query.answer("প্রোডাক্ট পাওয়া যায়নি।", show_alert=True)
            return
        text = (
            f"{item['emoji']} {item['name']}\n"
            f"👑 Limit: {item['limit']}\n"
            f"📊 Validity: {item['validity']}\n"
            f"💰 Price: {item['price_tk']} TK / {item['price_usdt']} USDT\n"
            f"📦 Stock: {item['stock'] if item['stock'] > 0 else 'OUT'}"
        )
        await query.edit_message_text(text, reply_markup=item_detail_keyboard(cat_key, item))
        return

    if data.startswith("buy:"):
        _, cat_key, item_id = data.split(":", 2)
        await handle_purchase(query, context, cat_key, item_id)
        return

    if data.startswith("admtop:"):
        await handle_admin_topup_decision(query, context, data)
        return


async def handle_purchase(query, context, cat_key, item_id):
    user_id = query.from_user.id
    item = storage.get_item(cat_key, item_id)
    if not item or item["stock"] <= 0:
        await query.answer("দুঃখিত, এই প্রোডাক্ট এখন Stock এ নেই।", show_alert=True)
        return

    balance = storage.get_balance(user_id)
    if balance < item["price_tk"]:
        await query.answer(
            f"❌ Balance অপর্যাপ্ত। প্রয়োজন {item['price_tk']} TK, আপনার আছে {balance} TK।",
            show_alert=True,
        )
        return

    if not storage.deduct_balance(user_id, item["price_tk"]):
        await query.answer("Order প্রসেস করা যায়নি, আবার চেষ্টা করুন।", show_alert=True)
        return
    storage.decrement_stock(cat_key, item_id)
    order_id = storage.create_order(user_id, cat_key, item_id, item["name"], item["price_tk"])

    await query.edit_message_text(
        f"✅ Order Confirmed! (#{order_id})\n\n"
        f"{item['emoji']} {item['name']}\n"
        f"💰 Paid: {item['price_tk']} TK\n\n"
        f"⏳ আপনার প্রোডাক্ট শীঘ্রই ডেলিভারি করা হবে। ধন্যবাদ!"
    )

    for admin_id in ADMIN_IDS:
        try:
            await context.bot.send_message(
                admin_id,
                f"🛒 New Order #{order_id}\n"
                f"👤 User: {query.from_user.full_name} (id: {user_id})\n"
                f"📦 Item: {item['name']}\n"
                f"💰 Price: {item['price_tk']} TK\n\n"
                f"➡️ এই order-এর credentials ম্যানুয়ালি ইউজারকে পাঠান।",
            )
        except Exception:
            logger.exception("Failed to notify admin %s", admin_id)


# ------------------------------------------------------------------
# Top-up conversation: method -> amount -> txn -> screenshot
# ------------------------------------------------------------------

async def topup_method_chosen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    _, method_key = query.data.split(":", 1)
    method = PAYMENT_METHODS.get(method_key)
    if not method:
        return ConversationHandler.END

    context.user_data["topup_method"] = method_key
    await query.edit_message_text(
        f"{method['label']}\n\n"
        f"📤 Send to: {method['number']}\n"
        f"📍 Minimum: {method['min_amount']} TK\n\n"
        f"➡️ এখন আপনার Amount পাঠান:",
        reply_markup=cancel_keyboard(),
    )
    return TOPUP_AMOUNT


async def topup_amount_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    try:
        amount = float(text)
        if amount <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            "❌ সঠিক Amount দিন (শুধু সংখ্যা)।", reply_markup=cancel_keyboard()
        )
        return TOPUP_AMOUNT

    context.user_data["topup_amount"] = amount
    await update.message.reply_text(
        f"✅ Amount: {amount} TK\n\n➡️ এখন আপনার Transaction ID / TXN Number পাঠান:",
        reply_markup=cancel_keyboard(),
    )
    return TOPUP_TXN


async def topup_txn_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    txn = update.message.text.strip()
    context.user_data["topup_txn"] = txn
    await update.message.reply_text(
        f"✅ TXN: {txn}\n\n"
        f"📸 এখন Payment-এর Screenshot পাঠান!\n"
        f"(শুধু Photo — Document বা Text নয়)\n\n"
        f"⚠️ Screenshot ছাড়া request accept হবে না।",
        reply_markup=cancel_keyboard(),
    )
    return TOPUP_SCREENSHOT


async def topup_screenshot_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.photo:
        await update.message.reply_text(
            "❌ শুধু Photo পাঠান (Document/Text নয়)।", reply_markup=cancel_keyboard()
        )
        return TOPUP_SCREENSHOT

    file_id = update.message.photo[-1].file_id
    user_id = update.effective_user.id
    method_key = context.user_data["topup_method"]
    amount = context.user_data["topup_amount"]
    txn = context.user_data["topup_txn"]
    method = PAYMENT_METHODS[method_key]

    req_id = storage.create_topup(user_id, method_key, amount, txn, file_id)

    await update.message.reply_text(
        f"⏳ TOP-UP REQUEST SUBMITTED!\n\n"
        f"💳 Method: {method['label']}\n"
        f"🧾 TXN: {txn}\n"
        f"💰 Amount: {amount} TK\n\n"
        f"📍 Admin verify করলে balance add হবে। অনুগ্রহ করে অপেক্ষা করুন!",
        reply_markup=main_menu_keyboard(),
    )

    for admin_id in ADMIN_IDS:
        try:
            await context.bot.send_photo(
                admin_id,
                photo=file_id,
                caption=(
                    f"💳 New Top-up Request #{req_id}\n"
                    f"👤 User: {update.effective_user.full_name} (id: {user_id})\n"
                    f"🏦 Method: {method['label']}\n"
                    f"💰 Amount: {amount} TK\n"
                    f"🧾 TXN: {txn}"
                ),
                reply_markup=admin_review_keyboard(req_id),
            )
        except Exception:
            logger.exception("Failed to notify admin %s", admin_id)

    context.user_data.clear()
    return ConversationHandler.END


async def topup_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data.clear()
    await query.edit_message_text("❌ Top-up বাতিল করা হয়েছে।")
    return ConversationHandler.END


# ------------------------------------------------------------------
# Admin: approve / reject top-up requests
# ------------------------------------------------------------------

async def handle_admin_topup_decision(query, context, data):
    if not is_admin(query.from_user.id):
        await query.answer("আপনি অনুমোদিত নন।", show_alert=True)
        return

    _, action, req_id_str = data.split(":", 2)
    req_id = int(req_id_str)
    req = storage.get_topup(req_id)
    if not req:
        await query.answer("Request পাওয়া যায়নি।", show_alert=True)
        return
    if req["status"] != "pending":
        await query.answer(f"এই request ইতিমধ্যে {req['status']}।", show_alert=True)
        return

    if action == "approve":
        storage.update_topup_status(req_id, "approved")
        new_balance = storage.add_balance(req["user_id"], req["amount"])
        await query.edit_message_caption(
            caption=query.message.caption + "\n\n✅ APPROVED"
        )
        try:
            await context.bot.send_message(
                req["user_id"],
                f"✅ আপনার Top-up #{req_id} Approve হয়েছে!\n"
                f"💰 Added: {req['amount']} TK\n"
                f"👛 New Balance: {new_balance} TK",
            )
        except Exception:
            logger.exception("Failed to notify user about approval")
    else:
        storage.update_topup_status(req_id, "rejected")
        await query.edit_message_caption(
            caption=query.message.caption + "\n\n❌ REJECTED"
        )
        try:
            await context.bot.send_message(
                req["user_id"],
                f"❌ আপনার Top-up #{req_id} Reject করা হয়েছে। সঠিক তথ্য দিয়ে আবার চেষ্টা করুন অথবা Support-এ যোগাযোগ করুন।",
            )
        except Exception:
            logger.exception("Failed to notify user about rejection")


# ------------------------------------------------------------------
# Admin utility commands
# ------------------------------------------------------------------

async def admin_stock(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/stock <category> <item_id> <qty>"""
    if not is_admin(update.effective_user.id):
        return
    args = context.args
    if len(args) != 3:
        await update.message.reply_text("ব্যবহার: /stock <category> <item_id> <qty>")
        return
    cat_key, item_id, qty = args
    try:
        qty = int(qty)
    except ValueError:
        await update.message.reply_text("qty অবশ্যই একটি সংখ্যা হতে হবে।")
        return
    if storage.set_stock(cat_key, item_id, qty):
        await update.message.reply_text(f"✅ Stock updated: {item_id} → {qty}")
    else:
        await update.message.reply_text("❌ Category/Item পাওয়া যায়নি।")


async def admin_addbalance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/addbalance <user_id> <amount>"""
    if not is_admin(update.effective_user.id):
        return
    args = context.args
    if len(args) != 2:
        await update.message.reply_text("ব্যবহার: /addbalance <user_id> <amount>")
        return
    user_id, amount = args
    try:
        user_id = int(user_id)
        amount = float(amount)
    except ValueError:
        await update.message.reply_text("user_id ও amount সঠিক ফরম্যাটে দিন।")
        return
    new_balance = storage.add_balance(user_id, amount)
    await update.message.reply_text(f"✅ {user_id} এর নতুন Balance: {new_balance} TK")
    try:
        await context.bot.send_message(
            user_id, f"💰 Admin আপনার একাউন্টে {amount} TK যোগ করেছেন। নতুন Balance: {new_balance} TK"
        )
    except Exception:
        pass


async def admin_myid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"আপনার Telegram ID: {update.effective_user.id}")


# ------------------------------------------------------------------
# App wiring
# ------------------------------------------------------------------

def main():
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN সেট করা নেই। .env ফাইলে BOT_TOKEN বসান।")

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("myid", admin_myid))
    app.add_handler(CommandHandler("stock", admin_stock))
    app.add_handler(CommandHandler("addbalance", admin_addbalance))

    topup_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(topup_method_chosen, pattern=r"^topup:")],
        states={
            TOPUP_AMOUNT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, topup_amount_received),
                CallbackQueryHandler(topup_cancel, pattern=r"^topup_cancel$"),
            ],
            TOPUP_TXN: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, topup_txn_received),
                CallbackQueryHandler(topup_cancel, pattern=r"^topup_cancel$"),
            ],
            TOPUP_SCREENSHOT: [
                MessageHandler(filters.PHOTO, topup_screenshot_received),
                MessageHandler(filters.TEXT & ~filters.COMMAND, topup_screenshot_received),
                CallbackQueryHandler(topup_cancel, pattern=r"^topup_cancel$"),
            ],
        },
        fallbacks=[CallbackQueryHandler(topup_cancel, pattern=r"^topup_cancel$")],
        per_message=False,
    )
    app.add_handler(topup_conv)

    # Everything else that isn't part of the top-up conversation
    app.add_handler(CallbackQueryHandler(callback_router))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, menu_router))

    logger.info("Bot starting...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
