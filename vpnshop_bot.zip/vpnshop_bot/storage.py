import json
import os
import threading
from config import DATA_DIR

_lock = threading.Lock()

PRODUCTS_FILE = os.path.join(DATA_DIR, "products.json")
USERS_FILE = os.path.join(DATA_DIR, "users.json")
TOPUPS_FILE = os.path.join(DATA_DIR, "topups.json")
ORDERS_FILE = os.path.join(DATA_DIR, "orders.json")


def _read(path, default):
    if not os.path.exists(path):
        return default
    with open(path, "r", encoding="utf-8") as f:
        content = f.read().strip()
        if not content:
            return default
        return json.loads(content)


def _write(path, data):
    with _lock:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)


# ---------------- Products ----------------

def get_products():
    return _read(PRODUCTS_FILE, {})


def save_products(products):
    _write(PRODUCTS_FILE, products)


def get_category(cat_key):
    return get_products().get(cat_key)


def get_item(cat_key, item_id):
    cat = get_category(cat_key)
    if not cat:
        return None
    for item in cat["items"]:
        if item["id"] == item_id:
            return item
    return None


def decrement_stock(cat_key, item_id):
    products = get_products()
    cat = products.get(cat_key)
    if not cat:
        return False
    for item in cat["items"]:
        if item["id"] == item_id:
            if item["stock"] <= 0:
                return False
            item["stock"] -= 1
            save_products(products)
            return True
    return False


def set_stock(cat_key, item_id, new_stock):
    products = get_products()
    cat = products.get(cat_key)
    if not cat:
        return False
    for item in cat["items"]:
        if item["id"] == item_id:
            item["stock"] = new_stock
            save_products(products)
            return True
    return False


# ---------------- Users / balance ----------------

def get_users():
    return _read(USERS_FILE, {})


def save_users(users):
    _write(USERS_FILE, users)


def get_user(user_id, name=None):
    users = get_users()
    uid = str(user_id)
    if uid not in users:
        users[uid] = {"name": name or "", "balance": 0, "referred_by": None}
        save_users(users)
    elif name and users[uid].get("name") != name:
        users[uid]["name"] = name
        save_users(users)
    return users[uid]


def get_balance(user_id):
    return get_user(user_id).get("balance", 0)


def add_balance(user_id, amount):
    users = get_users()
    uid = str(user_id)
    if uid not in users:
        users[uid] = {"name": "", "balance": 0, "referred_by": None}
    users[uid]["balance"] = round(users[uid].get("balance", 0) + amount, 2)
    save_users(users)
    return users[uid]["balance"]


def deduct_balance(user_id, amount):
    users = get_users()
    uid = str(user_id)
    if uid not in users or users[uid].get("balance", 0) < amount:
        return False
    users[uid]["balance"] = round(users[uid]["balance"] - amount, 2)
    save_users(users)
    return True


# ---------------- Top-up requests ----------------

def get_topups():
    return _read(TOPUPS_FILE, {"next_id": 1, "requests": []})


def save_topups(data):
    _write(TOPUPS_FILE, data)


def create_topup(user_id, method, amount, txn, screenshot_file_id):
    data = get_topups()
    req_id = data["next_id"]
    data["next_id"] += 1
    data["requests"].append({
        "id": req_id,
        "user_id": user_id,
        "method": method,
        "amount": amount,
        "txn": txn,
        "screenshot_file_id": screenshot_file_id,
        "status": "pending",
    })
    save_topups(data)
    return req_id


def get_topup(req_id):
    data = get_topups()
    for r in data["requests"]:
        if r["id"] == req_id:
            return r
    return None


def update_topup_status(req_id, status):
    data = get_topups()
    for r in data["requests"]:
        if r["id"] == req_id:
            r["status"] = status
            save_topups(data)
            return r
    return None


# ---------------- Orders ----------------

def get_orders():
    return _read(ORDERS_FILE, {"next_id": 1, "orders": []})


def save_orders(data):
    _write(ORDERS_FILE, data)


def create_order(user_id, cat_key, item_id, item_name, price_tk):
    data = get_orders()
    order_id = data["next_id"]
    data["next_id"] += 1
    data["orders"].append({
        "id": order_id,
        "user_id": user_id,
        "category": cat_key,
        "item_id": item_id,
        "item_name": item_name,
        "price_tk": price_tk,
    })
    save_orders(data)
    return order_id
