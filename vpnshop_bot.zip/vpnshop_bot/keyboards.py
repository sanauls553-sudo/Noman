from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from config import PAYMENT_METHODS

MAIN_CATEGORIES = [
    ("preorder_vpn", "💎 Pre- Order VPN"),
    ("chatgpt", "💎 ChatGPT Plus"),
    ("abc_proxy", "💎 ABC PROXY"),
    ("telegram_premium", "✈️ Telegram Premium"),
]


def main_menu_keyboard():
    """Bottom persistent menu, mirrors: Proxy Shop / VPN Shop / Products / Top-up / Balance / Refer / Status / Support."""
    rows = [
        [KeyboardButton("🌐 Proxy Shop"), KeyboardButton("🛡️ VPN Shop")],
        [KeyboardButton("💎 Products"), KeyboardButton("💳 Top-up")],
        [KeyboardButton("👛 Balance"), KeyboardButton("🎁 Refer")],
        [KeyboardButton("📊 Status"), KeyboardButton("💬 Support")],
    ]
    return ReplyKeyboardMarkup(rows, resize_keyboard=True)


def category_products_keyboard(cat_key, cat):
    """Inline list of items for a category, green=in stock red=out of stock, like the screenshots."""
    buttons = []
    for item in cat["items"]:
        if item["stock"] > 0:
            text = f"{item['emoji']} {item['name']} — {item['price_tk']} TK / {item['price_usdt']} USDT | Stock: {item['stock']}"
        else:
            text = f"{item['emoji']} {item['name']} — {item['price_tk']} TK / {item['price_usdt']} USDT | OUT"
        buttons.append([InlineKeyboardButton(text, callback_data=f"item:{cat_key}:{item['id']}")])
    buttons.append([InlineKeyboardButton("❌ Close", callback_data="close")])
    return InlineKeyboardMarkup(buttons)


def item_detail_keyboard(cat_key, item):
    buttons = []
    if item["stock"] > 0:
        buttons.append([InlineKeyboardButton("✅ Buy Now", callback_data=f"buy:{cat_key}:{item['id']}")])
    buttons.append([InlineKeyboardButton("⬅️ Back", callback_data=f"cat:{cat_key}")])
    buttons.append([InlineKeyboardButton("❌ Close", callback_data="close")])
    return InlineKeyboardMarkup(buttons)


def select_category_keyboard():
    """The 'Products' button -> SELECT CATEGORY list."""
    buttons = [[InlineKeyboardButton(label, callback_data=f"cat:{key}")] for key, label in MAIN_CATEGORIES]
    buttons.append([InlineKeyboardButton("❌ Close", callback_data="close")])
    return InlineKeyboardMarkup(buttons)


def topup_methods_keyboard():
    buttons = [
        [InlineKeyboardButton(m["label"], callback_data=f"topup:{key}")]
        for key, m in PAYMENT_METHODS.items()
    ]
    buttons.append([InlineKeyboardButton("❌ Close", callback_data="close")])
    return InlineKeyboardMarkup(buttons)


def cancel_keyboard():
    return InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="topup_cancel")]])


def admin_review_keyboard(req_id):
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ Approve", callback_data=f"admtop:approve:{req_id}"),
        InlineKeyboardButton("❌ Reject", callback_data=f"admtop:reject:{req_id}"),
    ]])
