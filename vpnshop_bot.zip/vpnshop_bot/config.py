import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")

# Comma separated telegram user IDs who can manage the shop, e.g. "123456789,987654321"
ADMIN_IDS = [
    int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()
]

SHOP_NAME = os.getenv("SHOP_NAME", "🛍️PremiumVPNShop🛍️")

# Payment receiving numbers / addresses shown to the customer during Top-up
PAYMENT_METHODS = {
    "bkash": {
        "label": "📲 বিকাশ",
        "number": os.getenv("BKASH_NUMBER", "01XXXXXXXXX (Send Money)"),
        "min_amount": 30,
    },
    "nagad": {
        "label": "🔴 নগদ",
        "number": os.getenv("NAGAD_NUMBER", "01XXXXXXXXX (Send Money)"),
        "min_amount": 30,
    },
    "binance": {
        "label": "🟡 Binance",
        "number": os.getenv("BINANCE_ID", "Binance Pay ID: XXXXXXXX"),
        "min_amount": 1,
    },
}

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
